import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs

ApplicationWindow {
    id: win
    width: 420; height: 850; visible: true
    title: "PaperToCBT"
    color: app.darkMode ? "#10141d" : "#f4f6fa"
    property color panel: app.darkMode ? "#1a2130" : "#ffffff"
    property color ink: app.darkMode ? "#f1f5fb" : "#182230"
    property color muted: app.darkMode ? "#a8b3c7" : "#667085"
    property color accent: "#5577e8"
    property int activeTab: 0
    property int selectedSubject: 0
    property var subjectNames: ["Physics", "Chemistry", "Mathematics"]
    property var visibleQuestions: {
        var a = [];
        for (var i=0; i<app.questions.length; i++)
            if (app.questions[i].subject === subjectNames[selectedSubject]) a.push(i);
        return a;
    }
    function fmtTime(s) { s=Math.max(0,s); return String(Math.floor(s/3600)).padStart(2,"0")+":"+String(Math.floor((s%3600)/60)).padStart(2,"0")+":"+String(s%60).padStart(2,"0") }
    function currentQ() { return app.questions.length ? app.questions[Math.min(app.currentIndex,app.questions.length-1)] : ({}) }
    function nextQ() { if(app.currentIndex < app.questions.length-1) app.currentIndex++ }
    function pickState(q) {
        if (!q.visited) return "#687386";
        if (q.review && q.response !== "") return "#8d5bd7";
        if (q.review) return "#d5a32e";
        if (q.response !== "") return "#239b70";
        return "#d94f59";
    }
    header: ToolBar {
        background: panel
        RowLayout {
            anchors.fill: parent; anchors.leftMargin: 14; anchors.rightMargin: 12
            Label { text: "PaperToCBT"; color: ink; font.pixelSize: 21; font.bold: true; Layout.fillWidth: true }
            ToolButton { text: app.darkMode ? "☀" : "☾"; onClicked: app.darkMode = !app.darkMode }
            ToolButton { text: "⚙"; onClicked: activeTab = 4 }
        }
    }
    footer: TabBar {
        id: tabs; currentIndex: activeTab
        background: Rectangle { color: panel }
        TabButton { text: "Create" }
        TabButton { text: "Review" }
        TabButton { text: "Exam" }
        TabButton { text: "History" }
        onCurrentIndexChanged: activeTab = currentIndex
    }
    FileDialog { id: pdfDialog; title: "Choose question paper PDF"; nameFilters: ["PDF files (*.pdf)"]; onAccepted: app.setFile("pdf", selectedFile) }
    FileDialog { id: keyDialog; title: "Choose answer key JPG"; nameFilters: ["Images (*.jpg *.jpeg *.png)"]; onAccepted: app.setFile("key", selectedFile) }
    FileDialog { id: exportDialog; title: "Export CSV"; fileMode: FileDialog.SaveFile; nameFilters: ["CSV files (*.csv)"]; onAccepted: app.exportHistoryCsv(selectedFile) }
    Connections { target: app; function onMessage(text) { toast.text = text; toast.open() } }
    Popup { id: toast; property alias text: toastLabel.text; x: 12; y: win.height-120; width: win.width-24; height: implicitHeight; padding: 12; modal: false; background: Rectangle { color: "#303a4d"; radius: 10 }; Label { id: toastLabel; color: "white"; wrapMode: Text.Wrap; width: parent.width } }
    ScrollView {
        anchors.fill: parent; clip: true
        ColumnLayout {
            width: win.width; spacing: 12
            visible: activeTab === 0
            Item { height: 3 }
            Label { text: "Create a CBT"; color: ink; font.pixelSize: 24; font.bold: true; Layout.leftMargin: 16 }
            Label { text: "Upload your paper and answer key. Review every extraction before the exam."; color: muted; wrapMode: Text.Wrap; Layout.leftMargin: 16; Layout.rightMargin: 16; Layout.fillWidth: true }
            Rectangle {
                Layout.fillWidth: true; Layout.leftMargin: 14; Layout.rightMargin: 14; radius: 14; color: panel; implicitHeight: createCol.implicitHeight+28
                ColumnLayout { id: createCol; anchors.fill: parent; anchors.margins: 14; spacing: 10
                    Label { text: "TEST NAME"; color: muted; font.bold: true; font.pixelSize: 12 }
                    TextField { Layout.fillWidth: true; placeholderText: "e.g. Allen Test 5"; text: app.testName; onTextEdited: app.testName=text }
                    Button { text: "＋  Select question paper (PDF)"; Layout.fillWidth: true; onClicked: pdfDialog.open() }
                    Button { text: "＋  Select answer key (JPG)"; Layout.fillWidth: true; onClicked: keyDialog.open() }
                    Label { text: "Selected files are processed by the AI endpoint configured in Settings."; color: muted; wrapMode: Text.Wrap; Layout.fillWidth: true }
                    Button { text: app.busy ? "Processing…" : "Process paper + answer key"; enabled: !app.busy; Layout.fillWidth: true; highlighted: true; onClicked: app.processFiles() }
                    ProgressBar { Layout.fillWidth: true; from: 0; to: 100; value: app.progress; visible: app.busy || app.progress>0 }
                    Label { text: app.stage; color: muted; wrapMode: Text.Wrap; Layout.fillWidth: true }
                }
            }
            Rectangle { Layout.fillWidth: true; Layout.leftMargin: 14; Layout.rightMargin: 14; radius: 14; color: panel; implicitHeight: 120
                ColumnLayout { anchors.fill: parent; anchors.margins: 14
                    Label { text: "Default JEE Main pattern"; color: ink; font.bold: true; font.pixelSize: 16 }
                    Label { text: "75 questions · 3 hours · +4 correct · −1 wrong · 0 unattempted"; color: muted; wrapMode: Text.Wrap; Layout.fillWidth: true }
                    Label { text: "20 MCQs + 5 numerical questions per subject"; color: muted; wrapMode: Text.Wrap; Layout.fillWidth: true }
                }
            }
            Item { height: 16 }
        }
        ColumnLayout {
            width: win.width; spacing: 10; visible: activeTab === 1
            Label { text: "Review extracted content"; color: ink; font.pixelSize: 23; font.bold: true; Layout.margins: 16 }
            Label { text: app.questions.length ? "Edit question text, options and answer key. Fix any OCR mistakes before starting." : "Process a paper first. Extracted questions will appear here."; color: muted; wrapMode: Text.Wrap; Layout.leftMargin: 16; Layout.rightMargin: 16; Layout.fillWidth: true }
            Repeater {
                model: app.questions
                delegate: Rectangle {
                    required property var modelData
                    required property int index
                    Layout.fillWidth: true; Layout.leftMargin: 12; Layout.rightMargin: 12
                    color: panel; radius: 12; implicitHeight: editCol.implicitHeight+22
                    ColumnLayout { id: editCol; anchors.fill: parent; anchors.margins: 11; spacing: 7
                        Label { text: "Q"+modelData.number+" · "+modelData.subject+" · Section "+modelData.section; color: accent; font.bold: true }
                        TextArea { Layout.fillWidth: true; implicitHeight: 100; wrapMode: TextEdit.Wrap; text: modelData.text || ""; placeholderText: "Question text"; onActiveFocusChanged: if (!activeFocus) app.updateQuestion(index, {"text":text}) }
                        Label { text: "Options (one per line; A–D)"; color: muted; visible: modelData.type !== "numerical" }
                        TextArea { Layout.fillWidth: true; implicitHeight: 86; visible: modelData.type !== "numerical"; text: (modelData.options || []).join("\n"); wrapMode: TextEdit.Wrap; onEditingFinished: app.updateQuestion(index, {"options":text.split("\n")}) }
                        RowLayout { Layout.fillWidth: true
                            Label { text: "Correct answer"; color: muted }
                            TextField { Layout.fillWidth: true; text: modelData.answer || ""; placeholderText: "A / B / C / D or number"; onEditingFinished: app.updateQuestion(index, {"answer":text.trim()}) }
                        }
                    }
                }
            }
            Button { text: "Start exam"; Layout.fillWidth: true; Layout.margins: 14; highlighted: true; enabled: app.questions.length>0; onClicked: { app.startExam(); activeTab=2; tabs.currentIndex=2 } }
            Item { height: 20 }
        }
        ColumnLayout {
            width: win.width; spacing: 10; visible: activeTab === 2
            RowLayout { Layout.fillWidth: true; Layout.margins: 12
                Label { text: app.testName; color: ink; font.bold: true; font.pixelSize: 18; Layout.fillWidth: true; elide: Text.ElideRight }
                Label { text: fmtTime(app.remainingSeconds); color: app.remainingSeconds<300 ? "#ff646d" : ink; font.bold: true; font.pixelSize: 18 }
            }
            RowLayout { Layout.fillWidth: true; Layout.leftMargin: 10; Layout.rightMargin: 10
                Repeater { model: subjectNames; delegate: Button { required property string modelData; required property int index; text: modelData; Layout.fillWidth: true; highlighted: selectedSubject===index; onClicked: { selectedSubject=index; var found=-1; for(var j=0;j<app.questions.length;j++) if(app.questions[j].subject===modelData){found=j;break;} if(found>=0)app.currentIndex=found } } }
            }
            Rectangle { Layout.fillWidth: true; Layout.leftMargin: 12; Layout.rightMargin: 12; radius: 12; color: panel; implicitHeight: examCol.implicitHeight+24
                ColumnLayout { id: examCol; anchors.fill: parent; anchors.margins: 14; spacing: 12
                    Label { text: app.questions.length ? "Question "+(currentQ().number || app.currentIndex+1)+"  /  "+app.questions.length : "No test loaded"; color: ink; font.bold: true; font.pixelSize: 17 }
                    Label { text: (currentQ().subject||"")+" · Section "+(currentQ().section||""); color: muted }
                    Text { text: currentQ().text || "Create a test and start the exam to see questions here."; color: ink; wrapMode: Text.Wrap; Layout.fillWidth: true; font.pixelSize: 17 }
                    Image { visible: !!currentQ().diagramBase64; source: currentQ().diagramBase64 ? (currentQ().diagramBase64.startsWith("data:")?currentQ().diagramBase64:"data:image/png;base64,"+currentQ().diagramBase64) : ""; fillMode: Image.PreserveAspectFit; Layout.fillWidth: true; Layout.preferredHeight: visible?180:0 }
                    Repeater { model: currentQ().type==="numerical" ? 0 : (currentQ().options||[]).length
                        delegate: RadioButton { required property int index; text: ["A","B","C","D"][index]+". "+(currentQ().options||[])[index]; checked: currentQ().response === ["A","B","C","D"][index]; onClicked: app.setResponse(app.currentIndex,["A","B","C","D"][index]); contentItem: Text { text: parent.text; color: ink; wrapMode: Text.Wrap; leftPadding: 4 } }
                    }
                    Label { text: "Numerical answer"; color: muted; visible: currentQ().type==="numerical" }
                    TextField { id: numAnswer; visible: currentQ().type==="numerical"; Layout.fillWidth: true; inputMethodHints: Qt.ImhFormattedNumbersOnly; text: currentQ().response||""; onTextEdited: app.setResponse(app.currentIndex,text) }
                    GridLayout { visible: currentQ().type==="numerical"; columns: 3; Layout.fillWidth: true
                        Repeater { model: ["7","8","9","4","5","6","1","2","3","−","0",".","⌫","Clear"]
                            delegate: Button { required property string modelData; text: modelData; Layout.fillWidth: true; onClicked: {
                                var s=currentQ().response||"";
                                if(modelData==="Clear")s="";
                                else if(modelData==="⌫")s=s.slice(0,-1);
                                else if(modelData==="−")s=s.startsWith("-")?s.slice(1):"-"+s;
                                else s+=modelData;
                                app.setResponse(app.currentIndex,s);
                            }}
                        }
                    }
                    RowLayout { Layout.fillWidth: true
                        Button { text: "Clear Response"; Layout.fillWidth: true; onClicked: app.clearResponse(app.currentIndex) }
                        Button { text: currentQ().review ? "Unmark Review" : "Mark Review"; Layout.fillWidth: true; onClicked: app.toggleReview(app.currentIndex) }
                    }
                    GridLayout { columns: 5; Layout.fillWidth: true
                        Repeater { model: app.questions
                            delegate: Button {
                                required property var modelData; required property int index
                                visible: modelData.subject===subjectNames[selectedSubject]
                                text: String(modelData.number||index+1); Layout.fillWidth: true
                                background: Rectangle { radius: 7; color: pickState(modelData) }
                                contentItem: Text { text: parent.text; color: "white"; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter }
                                onClicked: { app.currentIndex=index; var q=app.questions[index]; if(!q.visited)app.updateQuestion(index,{"visited":true}) }
                            }
                        }
                    }
                    RowLayout { Layout.fillWidth: true
                        Button { text: "Save & Next"; Layout.fillWidth: true; highlighted: true; onClicked: { app.updateQuestion(app.currentIndex,{"visited":true}); nextQ() } }
                        Button { text: "Submit"; Layout.fillWidth: true; onClicked: confirmSubmit.open() }
                    }
                }
            }
            Label { text: "Palette: grey not visited · red not answered · green answered · amber review · purple answered + review"; color: muted; wrapMode: Text.Wrap; Layout.leftMargin: 14; Layout.rightMargin: 14; Layout.fillWidth: true; font.pixelSize: 11 }
            Item { height: 16 }
        }
        ColumnLayout {
            width: win.width; spacing: 12; visible: activeTab === 3
            Label { text: "Attempt history"; color: ink; font.pixelSize: 23; font.bold: true; Layout.margins: 16 }
            RowLayout { Layout.fillWidth: true; Layout.leftMargin: 14; Layout.rightMargin: 14
                Button { text: "Export all CSV"; Layout.fillWidth: true; onClicked: exportDialog.open() }
                Button { text: "Clear history"; onClicked: clearHistoryConfirm.open() }
            }
            Repeater {
                model: app.history
                delegate: Rectangle {
                    required property var modelData; required property int index
                    Layout.fillWidth: true; Layout.leftMargin: 12; Layout.rightMargin: 12; color: panel; radius: 12; implicitHeight: histCol.implicitHeight+24
                    ColumnLayout { id: histCol; anchors.fill: parent; anchors.margins: 12; spacing: 6
                        Label { text: modelData.name || "Practice Test"; color: ink; font.bold: true; font.pixelSize: 17 }
                        Label { text: (modelData.date||"")+" · Score: "+modelData.score; color: accent; wrapMode: Text.Wrap; Layout.fillWidth: true }
                        Label { text: "P "+((modelData.subjects||{}).Physics||{}).score+" · C "+((modelData.subjects||{}).Chemistry||{}).score+" · M "+((modelData.subjects||{}).Mathematics||{}).score; color: muted }
                        Button { text: "Export question-wise CSV"; onClicked: { exportAttemptDialog.historyIndex=index; exportAttemptDialog.open() } }
                    }
                }
            }
            Item { height: 20 }
        }
        ColumnLayout {
            width: win.width; spacing: 12; visible: activeTab === 4
            Label { text: "Settings"; color: ink; font.pixelSize: 23; font.bold: true; Layout.margins: 16 }
            Rectangle { Layout.fillWidth: true; Layout.leftMargin: 12; Layout.rightMargin: 12; color: panel; radius: 12; implicitHeight: settingsCol.implicitHeight+24
                ColumnLayout { id: settingsCol; anchors.fill: parent; anchors.margins: 14; spacing: 10
                    Label { text: "AI / OCR endpoint"; color: ink; font.bold: true }
                    TextField { Layout.fillWidth: true; placeholderText: "https://your-backend.example/process"; text: app.endpoint; onTextEdited: app.endpoint=text }
                    Label { text: "Bearer API key (avoid embedding production keys in APK)"; color: muted; wrapMode: Text.Wrap; Layout.fillWidth: true }
                    TextField { Layout.fillWidth: true; placeholderText: "API key"; echoMode: TextInput.Password; text: app.apiKey; onTextEdited: app.apiKey=text }
                    Label { text: "Exam pattern"; color: ink; font.bold: true }
                    RowLayout { Label { text: "Duration (minutes)"; color: muted; Layout.fillWidth: true }; SpinBox { from: 1; to: 600; value: app.durationMinutes; onValueModified: app.durationMinutes=value } }
                    RowLayout { Label { text: "Question count"; color: muted; Layout.fillWidth: true }; SpinBox { from: 1; to: 300; value: app.totalQuestions; onValueModified: app.totalQuestions=value } }
                    RowLayout { Label { text: "Marks for correct"; color: muted; Layout.fillWidth: true }; SpinBox { from: 0; to: 20; value: app.positiveMarks; onValueModified: app.positiveMarks=value } }
                    RowLayout { Label { text: "Penalty for wrong"; color: muted; Layout.fillWidth: true }; SpinBox { from: 0; to: 20; value: app.negativeMarks; onValueModified: app.negativeMarks=value } }
                    Switch { text: "Dark mode"; checked: app.darkMode; onToggled: app.darkMode=checked }
                }
            }
            Item { height: 20 }
        }
        ColumnLayout {
            width: win.width; spacing: 12; visible: activeTab === 5
            Label { text: "Test result"; color: ink; font.pixelSize: 24; font.bold: true; Layout.margins: 16 }
            Rectangle { Layout.fillWidth: true; Layout.leftMargin: 12; Layout.rightMargin: 12; color: panel; radius: 14; implicitHeight: resultCol.implicitHeight+28
                ColumnLayout { id: resultCol; anchors.fill: parent; anchors.margins: 16; spacing: 8
                    Label { text: "Score: "+app.results().score; color: accent; font.pixelSize: 28; font.bold: true }
                    Label { text: "Correct: "+app.results().correct+"   Wrong: "+app.results().wrong+"   Unattempted: "+app.results().unattempted; color: ink; wrapMode: Text.Wrap; Layout.fillWidth: true }
                    Label { text: "Accuracy: "+Number(app.results().accuracy).toFixed(1)+"%"; color: muted }
                    Label { text: "Time spent: "+fmtTime(app.results().timeSpent); color: muted }
                    Repeater { model: ["Physics","Chemistry","Mathematics"]
                        delegate: Rectangle { required property string modelData; Layout.fillWidth: true; radius: 8; color: win.color
                            implicitHeight: 58
                            RowLayout { anchors.fill: parent; anchors.margins: 10
                                Label { text: modelData; color: ink; Layout.fillWidth: true }
                                Label { text: "Score "+(((app.results().subjects||{})[modelData]||{}).score||0); color: accent; font.bold: true }
                            }
                        }
                    }
                    Button { text: "Back to History"; Layout.fillWidth: true; onClicked: { activeTab=3; tabs.currentIndex=3 } }
                    Button { text: "Review answers below"; Layout.fillWidth: true; onClicked: resultReview.visible=!resultReview.visible }
                }
            }
            ColumnLayout { id: resultReview; visible: false; Layout.fillWidth: true; spacing: 8
                Repeater { model: app.questions
                    delegate: Rectangle { required property var modelData; required property int index; Layout.fillWidth: true; Layout.leftMargin: 12; Layout.rightMargin: 12; radius: 10; color: panel; implicitHeight: reviewCol.implicitHeight+20
                        ColumnLayout { id: reviewCol; anchors.fill: parent; anchors.margins: 10
                            Label { text: "Q"+modelData.number+" · "+modelData.subject; color: accent; font.bold: true }
                            Text { text: modelData.text||""; color: ink; wrapMode: Text.Wrap; Layout.fillWidth: true }
                            Label { text: "Your answer: "+(modelData.response||"Unattempted")+" · Correct answer: "+(modelData.answer||"Unknown"); color: muted; wrapMode: Text.Wrap; Layout.fillWidth: true }
                        }
                    }
                }
            }
            Item { height: 20 }
        }
    }
    Dialog { id: confirmSubmit; title: "Submit test?"; standardButtons: Dialog.Yes | Dialog.No; onAccepted: { app.submitExam(); activeTab=5 } ; contentItem: Label { text: "Your answers will be scored and saved to history."; color: ink; padding: 16; wrapMode: Text.Wrap } }
    Dialog { id: clearHistoryConfirm; title: "Clear all history?"; standardButtons: Dialog.Yes | Dialog.No; onAccepted: app.deleteHistory(); contentItem: Label { text: "This permanently deletes locally saved attempts."; color: ink; padding: 16 } }
    FileDialog { id: exportAttemptDialog; property int historyIndex: -1; title: "Export attempt CSV"; fileMode: FileDialog.SaveFile; nameFilters: ["CSV files (*.csv)"]; onAccepted: app.exportAttemptCsv(historyIndex, selectedFile) }
}
