#pragma once
#include <QObject>
#include <QVariantList>
#include <QVariantMap>
#include <QNetworkAccessManager>
#include <QTimer>

class AppController : public QObject {
    Q_OBJECT
    Q_PROPERTY(QVariantList questions READ questions NOTIFY questionsChanged)
    Q_PROPERTY(QVariantList history READ history NOTIFY historyChanged)
    Q_PROPERTY(QString stage READ stage NOTIFY stageChanged)
    Q_PROPERTY(int progress READ progress NOTIFY progressChanged)
    Q_PROPERTY(bool busy READ busy NOTIFY busyChanged)
    Q_PROPERTY(bool examActive READ examActive NOTIFY examActiveChanged)
    Q_PROPERTY(bool submitted READ submitted NOTIFY submittedChanged)
    Q_PROPERTY(int currentIndex READ currentIndex WRITE setCurrentIndex NOTIFY currentIndexChanged)
    Q_PROPERTY(int remainingSeconds READ remainingSeconds NOTIFY remainingSecondsChanged)
    Q_PROPERTY(QString testName READ testName WRITE setTestName NOTIFY testNameChanged)
    Q_PROPERTY(QString endpoint READ endpoint WRITE setEndpoint NOTIFY endpointChanged)
    Q_PROPERTY(QString apiKey READ apiKey WRITE setApiKey NOTIFY apiKeyChanged)
    Q_PROPERTY(bool darkMode READ darkMode WRITE setDarkMode NOTIFY darkModeChanged)
    Q_PROPERTY(int durationMinutes READ durationMinutes WRITE setDurationMinutes NOTIFY patternChanged)
    Q_PROPERTY(int totalQuestions READ totalQuestions WRITE setTotalQuestions NOTIFY patternChanged)
    Q_PROPERTY(int positiveMarks READ positiveMarks WRITE setPositiveMarks NOTIFY patternChanged)
    Q_PROPERTY(int negativeMarks READ negativeMarks WRITE setNegativeMarks NOTIFY patternChanged)
public:
    explicit AppController(QObject *parent=nullptr);
    QVariantList questions() const { return m_questions; }
    QVariantList history() const { return m_history; }
    QString stage() const { return m_stage; }
    int progress() const { return m_progress; }
    bool busy() const { return m_busy; }
    bool examActive() const { return m_examActive; }
    bool submitted() const { return m_submitted; }
    int currentIndex() const { return m_currentIndex; }
    void setCurrentIndex(int v);
    int remainingSeconds() const { return m_remainingSeconds; }
    QString testName() const { return m_testName; }
    void setTestName(const QString &v);
    QString endpoint() const { return m_endpoint; }
    void setEndpoint(const QString &v);
    QString apiKey() const { return m_apiKey; }
    void setApiKey(const QString &v);
    bool darkMode() const { return m_darkMode; }
    void setDarkMode(bool v);
    int durationMinutes() const { return m_durationMinutes; }
    void setDurationMinutes(int v);
    int totalQuestions() const { return m_totalQuestions; }
    void setTotalQuestions(int v);
    int positiveMarks() const { return m_positiveMarks; }
    void setPositiveMarks(int v);
    int negativeMarks() const { return m_negativeMarks; }
    void setNegativeMarks(int v);

    Q_INVOKABLE void setFile(const QString &kind, const QUrl &url);
    Q_INVOKABLE void processFiles();
    Q_INVOKABLE void updateQuestion(int index, const QVariantMap &patch);
    Q_INVOKABLE void startExam();
    Q_INVOKABLE void setResponse(int index, const QString &response);
    Q_INVOKABLE void clearResponse(int index);
    Q_INVOKABLE void toggleReview(int index);
    Q_INVOKABLE void submitExam();
    Q_INVOKABLE QVariantMap results() const;
    Q_INVOKABLE void exportHistoryCsv(const QUrl &destination);
    Q_INVOKABLE void exportAttemptCsv(int historyIndex, const QUrl &destination);
    Q_INVOKABLE void deleteHistory();
signals:
    void questionsChanged(); void historyChanged(); void stageChanged();
    void progressChanged(); void busyChanged(); void examActiveChanged();
    void submittedChanged(); void currentIndexChanged(); void remainingSecondsChanged();
    void testNameChanged(); void endpointChanged(); void apiKeyChanged();
    void darkModeChanged(); void patternChanged(); void message(QString text);
private slots:
    void tick();
private:
    void setStage(const QString &s, int p);
    QByteArray readFile(const QUrl &url) const;
    void loadHistory(); void saveHistory();
    QVariantList m_questions, m_history;
    QString m_stage="Ready", m_testName="Practice Test", m_endpoint, m_apiKey;
    QUrl m_pdfUrl, m_keyUrl;
    QNetworkAccessManager m_network;
    QTimer m_timer;
    bool m_busy=false, m_examActive=false, m_submitted=false, m_darkMode=true;
    int m_progress=0, m_currentIndex=0, m_remainingSeconds=10800;
    int m_durationMinutes=180, m_totalQuestions=75, m_positiveMarks=4, m_negativeMarks=1;
};
