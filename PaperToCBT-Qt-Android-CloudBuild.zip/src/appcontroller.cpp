#include "appcontroller.h"
#include <QFile>
#include <QFileInfo>
#include <QStandardPaths>
#include <QDir>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QFileDialog>
#include <QDateTime>
#include <QSaveFile>
#include <QUrlQuery>

static QString dataPath(const QString &name) {
    return QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/" + name;
}
AppController::AppController(QObject *parent) : QObject(parent) {
    QDir().mkpath(QStandardPaths::writableLocation(QStandardPaths::AppDataLocation));
    connect(&m_timer, &QTimer::timeout, this, &AppController::tick);
    m_timer.setInterval(1000);
    loadHistory();
}
void AppController::setCurrentIndex(int v) {
    int n=qMax(0, m_questions.size()-1); v=qBound(0,v,n);
    if(m_currentIndex==v)return; m_currentIndex=v; emit currentIndexChanged();
}
void AppController::setTestName(const QString&v){if(m_testName==v)return;m_testName=v;emit testNameChanged();}
void AppController::setEndpoint(const QString&v){m_endpoint=v;emit endpointChanged();}
void AppController::setApiKey(const QString&v){m_apiKey=v;emit apiKeyChanged();}
void AppController::setDarkMode(bool v){m_darkMode=v;emit darkModeChanged();}
void AppController::setDurationMinutes(int v){m_durationMinutes=qBound(1,v,600);emit patternChanged();}
void AppController::setTotalQuestions(int v){m_totalQuestions=qBound(1,v,300);emit patternChanged();}
void AppController::setPositiveMarks(int v){m_positiveMarks=v;emit patternChanged();}
void AppController::setNegativeMarks(int v){m_negativeMarks=qMax(0,v);emit patternChanged();}
void AppController::setStage(const QString&s,int p){m_stage=s;m_progress=p;emit stageChanged();emit progressChanged();}
void AppController::setFile(const QString&kind,const QUrl&url){
    if(kind=="pdf")m_pdfUrl=url; else m_keyUrl=url;
    emit message(kind=="pdf"?"Question paper selected":"Answer key selected");
}
QByteArray AppController::readFile(const QUrl&url) const {
    QString path=url.isLocalFile()?url.toLocalFile():url.toString();
    QFile f(path); if(!f.open(QIODevice::ReadOnly))return {};
    return f.readAll();
}
void AppController::processFiles(){
    if(m_busy)return;
    if(m_pdfUrl.isEmpty()||m_keyUrl.isEmpty()){emit message("Choose both the PDF paper and JPG answer key.");return;}
    if(m_endpoint.trimmed().isEmpty()){emit message("Set your AI/OCR endpoint in Settings first.");return;}
    QByteArray pdf=readFile(m_pdfUrl), key=readFile(m_keyUrl);
    if(pdf.isEmpty()||key.isEmpty()){emit message("Could not read one of the selected files. Try selecting it again.");return;}
    m_busy=true;emit busyChanged();setStage("Reading PDF and answer key",10);
    QJsonObject payload;
    payload["testName"]=m_testName;
    payload["pdfBase64"]=QString::fromLatin1(pdf.toBase64());
    payload["answerKeyBase64"]=QString::fromLatin1(key.toBase64());
    payload["instruction"]=QStringLiteral(
      "Extract only real questions from the entire PDF. Ignore ads, headers, footers, watermarks, page numbers and instructions. "
      "Keep question and options separate. Preserve math using LaTeX. Detect and crop diagrams, graphs, circuits, tables and images in options; "
      "return diagramBase64 as a data-free base64 PNG string when possible. Read the answer-key JPG using vision/OCR, map every key to question number, "
      "normalize MCQ answer to A/B/C/D and numerical answers to text. Do not invent uncertain content. "
      "Return JSON object {questions:[{number,subject,section,type,text,options,answer,diagramBase64,explanation}]}. "
      "subject must be Physics/Chemistry/Mathematics; section A/B; type mcq/numerical; options array for MCQ.");
    QNetworkRequest req{QUrl(m_endpoint)};
    req.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    if(!m_apiKey.isEmpty())req.setRawHeader("Authorization", QByteArray("Bearer ")+m_apiKey.toUtf8());
    req.setTransferTimeout(270000);
    setStage("Finding questions and extracting diagrams",25);
    QNetworkReply *reply=m_network.post(req,QJsonDocument(payload).toJson(QJsonDocument::Compact));
    connect(reply,&QNetworkReply::uploadProgress,this,[this](qint64 sent,qint64 total){
        if(total>0){setStage("Uploading files for AI/OCR",qBound(10,10+int(20.0*sent/total),30));}
    });
    connect(reply,&QNetworkReply::finished,this,[this,reply](){
        QByteArray bytes=reply->readAll(); int status=reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        if(reply->error()!=QNetworkReply::NoError || status<200 || status>=300){
            QString err=reply->errorString()+ (bytes.isEmpty()?"":" — "+QString::fromUtf8(bytes.left(500)));
            m_busy=false;emit busyChanged();setStage("Processing failed",0);emit message("AI/OCR request failed: "+err);reply->deleteLater();return;
        }
        setStage("Reading answer key and matching answers",80);
        QJsonParseError pe; QJsonDocument doc=QJsonDocument::fromJson(bytes,&pe);
        QJsonObject root=doc.object();
        if(!root.contains("questions") && root.contains("choices")) root["questions"]=root["choices"];
        QJsonArray arr=root.value("questions").toArray(); QVariantList parsed;
        for(const auto &v:arr){
            QVariantMap q=v.toObject().toVariantMap();
            q["response"]=""; q["visited"]=false; q["review"]=false; q["secondsSpent"]=0;
            if(q.value("subject").toString().isEmpty())q["subject"]="Physics";
            if(q.value("section").toString().isEmpty())q["section"]="A";
            if(q.value("type").toString().isEmpty())q["type"]="mcq";
            parsed<<q;
        }
        if(parsed.isEmpty()){
            m_busy=false;emit busyChanged();setStage("No questions found",0);emit message("The service returned no questions. Check the endpoint's JSON response.");reply->deleteLater();return;
        }
        m_questions=parsed;emit questionsChanged();m_currentIndex=0;emit currentIndexChanged();
        m_busy=false;emit busyChanged();setStage("Review extracted questions and answers",100);
        emit message(QString("Extracted %1 questions. Review and correct them before starting.").arg(parsed.size()));
        reply->deleteLater();
    });
}
void AppController::updateQuestion(int index,const QVariantMap&patch){
    if(index<0||index>=m_questions.size())return;
    QVariantMap q=m_questions[index].toMap(); for(auto it=patch.begin();it!=patch.end();++it)q[it.key()]=it.value();
    m_questions[index]=q;emit questionsChanged();
}
void AppController::startExam(){
    if(m_questions.isEmpty()){emit message("Process a paper and review the extracted questions first.");return;}
    m_submitted=false;m_examActive=true;m_remainingSeconds=m_durationMinutes*60;m_currentIndex=0;
    for(int i=0;i<m_questions.size();++i){auto q=m_questions[i].toMap();q["visited"]=false;q["response"]="";q["review"]=false;q["secondsSpent"]=0;m_questions[i]=q;}
    emit questionsChanged();emit submittedChanged();emit examActiveChanged();emit currentIndexChanged();emit remainingSecondsChanged();m_timer.start();
}
void AppController::setResponse(int i,const QString&r){if(i<0||i>=m_questions.size())return;auto q=m_questions[i].toMap();q["response"]=r;q["visited"]=true;m_questions[i]=q;emit questionsChanged();}
void AppController::clearResponse(int i){setResponse(i,"");}
void AppController::toggleReview(int i){if(i<0||i>=m_questions.size())return;auto q=m_questions[i].toMap();q["review"]=!q.value("review").toBool();q["visited"]=true;m_questions[i]=q;emit questionsChanged();}
void AppController::tick(){
    if(!m_examActive)return;
    if(m_remainingSeconds<=0){submitExam();return;}
    --m_remainingSeconds;
    if(m_currentIndex>=0&&m_currentIndex<m_questions.size()){auto q=m_questions[m_currentIndex].toMap();q["secondsSpent"]=q.value("secondsSpent").toInt()+1;m_questions[m_currentIndex]=q;}
    emit remainingSecondsChanged();emit questionsChanged();
}
QVariantMap AppController::results() const{
    QVariantMap out;int correct=0,wrong=0,unattempted=0;QVariantMap subs;
    for(const auto&v:m_questions){auto q=v.toMap();QString sub=q.value("subject").toString();QVariantMap s=subs.value(sub).toMap();
        QString response=q.value("response").toString().trimmed(), answer=q.value("answer").toString().trimmed();
        bool attempted=!response.isEmpty(); bool right=false;\n        if(attempted && q.value("type").toString()=="numerical"){ bool ok1=false,ok2=false; double a=response.toDouble(&ok1),b=answer.toDouble(&ok2); right=ok1&&ok2&&qAbs(a-b)<1e-8; }\n        else right=attempted && response.compare(answer,Qt::CaseInsensitive)==0;
        if(!attempted)++unattempted;else if(right)++correct;else ++wrong;
        int score=right?m_positiveMarks:(attempted?-m_negativeMarks:0);
        s["score"]=s.value("score").toInt()+score;s["correct"]=s.value("correct").toInt()+(right?1:0);
        s["wrong"]=s.value("wrong").toInt()+(attempted&&!right?1:0);s["unattempted"]=s.value("unattempted").toInt()+(!attempted?1:0);subs[sub]=s;
    }
    int attempted=correct+wrong;out["correct"]=correct;out["wrong"]=wrong;out["unattempted"]=unattempted;
    out["score"]=correct*m_positiveMarks-wrong*m_negativeMarks;out["accuracy"]=attempted?100.0*correct/attempted:0;
    out["subjects"]=subs;out["questions"]=m_questions;out["timeSpent"]=m_durationMinutes*60-m_remainingSeconds;return out;
}
void AppController::submitExam(){
    if(m_submitted)return;m_timer.stop();m_examActive=false;m_submitted=true;
    QVariantMap r=results();QVariantMap h;
    h["name"]=m_testName;h["date"]=QDateTime::currentDateTime().toString(Qt::ISODate);
    h["score"]=r["score"];h["subjects"]=r["subjects"];h["correct"]=r["correct"];h["wrong"]=r["wrong"];h["unattempted"]=r["unattempted"];
    h["questions"]=m_questions;h["durationMinutes"]=m_durationMinutes;m_history.prepend(h);saveHistory();
    emit examActiveChanged();emit submittedChanged();emit historyChanged();emit questionsChanged();setStage("Submitted",100);
}
void AppController::loadHistory(){
    QFile f(dataPath("history.json"));if(!f.open(QIODevice::ReadOnly))return;
    auto d=QJsonDocument::fromJson(f.readAll());for(auto v:d.array())m_history<<v.toObject().toVariantMap();emit historyChanged();
}
void AppController::saveHistory(){
    QJsonArray a;for(const auto&h:m_history)a.append(QJsonObject::fromVariantMap(h));
    QSaveFile f(dataPath("history.json"));if(f.open(QIODevice::WriteOnly)){f.write(QJsonDocument(a).toJson());f.commit();}
}
void AppController::deleteHistory(){m_history.clear();saveHistory();emit historyChanged();}
static QString csv(QString s){s.replace("\"","\"\"");return "\""+s+"\"";}
static bool writeCsv(const QUrl&url,const QString&content){
    QString p=url.isLocalFile()?url.toLocalFile():url.toString();QSaveFile f(p);
    if(!f.open(QIODevice::WriteOnly|QIODevice::Text))return false;
    f.write(content.toUtf8());return f.commit();
}
void AppController::exportHistoryCsv(const QUrl&url){
    QString out="Test,Date,Total Score,Physics,Chemistry,Mathematics,Correct,Wrong,Unattempted\n";
    for(const auto&v:m_history){auto h=v.toMap(); auto s=h.value("subjects").toMap();
      out+=csv(h.value("name").toString())+","+csv(h.value("date").toString())+","+QString::number(h.value("score").toInt())+",";
      out+=QString::number(s.value("Physics").toMap().value("score").toInt())+","+QString::number(s.value("Chemistry").toMap().value("score").toInt())+","+QString::number(s.value("Mathematics").toMap().value("score").toInt())+",";
      out+=QString::number(h.value("correct").toInt())+","+QString::number(h.value("wrong").toInt())+","+QString::number(h.value("unattempted").toInt())+"\n";
    }
    emit message(writeCsv(url,out)?"History CSV exported":"Could not write CSV. Choose a writable destination.");
}
void AppController::exportAttemptCsv(int hi,const QUrl&url){
    if(hi<0||hi>=m_history.size())return;auto h=m_history[hi].toMap();
    QString out="Test,Date,Question,Subject,Section,Question Text,Response,Answer,Correct,Seconds Spent\n";
    for(const auto&v:h.value("questions").toList()){auto q=v.toMap();QString resp=q.value("response").toString(),ans=q.value("answer").toString();
      out+=csv(h.value("name").toString())+","+csv(h.value("date").toString())+","+QString::number(q.value("number").toInt())+","+csv(q.value("subject").toString())+","+csv(q.value("section").toString())+","+csv(q.value("text").toString())+","+csv(resp)+","+csv(ans)+","+((!resp.isEmpty()&&resp.compare(ans,Qt::CaseInsensitive)==0)?"Yes":"No")+","+QString::number(q.value("secondsSpent").toInt())+"\n";
    }
    emit message(writeCsv(url,out)?"Attempt CSV exported":"Could not write CSV. Choose a writable destination.");
}
