# PaperToCBT — Qt/C++ Android starter

PaperToCBT is a mobile-first Qt 6 / C++ project scaffold for turning a coaching PDF + answer-key JPG into a JEE Main-style CBT.

## Included
- Qt Quick / QML mobile UI with dark-mode toggle
- PDF and JPG file selection, custom test name
- AI/OCR service configuration (endpoint + API key)
- Processing-stage progress UI
- Editable question/answer review before starting
- 75-question default JEE pattern, subject tabs, palette states, 180-minute timer
- MCQ and numerical responses, on-screen numerical keypad
- Save & Next, Clear Response, Mark for Review & Next, submit
- +4 / -1 / 0 scoring, subject-wise result summary, question review
- Local JSON attempt history and CSV exports (whole history and individual attempt)

## Important production notes
This is a functional UI/application scaffold, not a bundled OCR model or hosted AI service. Accurate extraction needs a reachable vision/OCR endpoint. Configure the endpoint and API key in the app. The sample request contract is documented below. Never ship a private API key inside an APK; use a small authenticated backend/proxy for production.

The app sends the PDF and answer-key image as base64 data to the configured endpoint. The endpoint should return JSON matching this schema:
```json
{
  "questions": [
    {
      "number": 1,
      "subject": "Physics",
      "section": "A",
      "type": "mcq",
      "text": "Question text; use LaTeX delimiters such as $\\\\frac{a}{b}$",
      "options": ["option A", "option B", "option C", "option D"],
      "answer": "A",
      "diagramBase64": "",
      "explanation": ""
    }
  ]
}
```
The service must OCR the whole PDF, detect question boundaries across pages, crop relevant diagrams/options, and match the answer-key format. Validate all output in the in-app review screen. Endpoint is expected to accept POST JSON:
`{"testName":"...","pdfBase64":"...","answerKeyBase64":"...","instruction":"..."}`
and return the schema above. The service may be an OpenAI-compatible vision model wrapper, Azure Document Intelligence wrapper, or a private API. Configure its full URL in settings.

## Build
1. Install Qt 6 with Qt Quick, Qt Quick Controls, Qt Network, and Android kits (Qt PDF is optional).
2. Open `CMakeLists.txt` in Qt Creator.
3. Select an Android arm64-v8a kit and configure Android SDK/NDK/JDK.
4. Set your AI endpoint and key in the app's Processing settings.
5. Build and deploy to your device.

For a real release, add TLS certificate policy, backend authentication/rate limits, PDF/image size limits, service-side timeout and retry, privacy consent, and automated tests against real coaching papers. The 5-minute processing target depends on file size and service latency and cannot be guaranteed without testing.


## Phone-only build attempt (GitHub Actions)
The `.github/workflows/android.yml` workflow provides an experimental cloud build. From a phone, upload the project to a GitHub repository, then open Actions → Build PaperToCBT Android APK → Run workflow. If the build succeeds, download the `PaperToCBT-Android-APK` artifact. Android/Qt version combinations can require adjustments; inspect the workflow logs if no APK is produced. A successful APK still needs a configured AI endpoint to process papers.
